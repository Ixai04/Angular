export interface Anuncio {
    foto: string;
    alternativo: string;
    ruta: string;
}
